/**
 * Repository-wide ndscm configuration, defined in `REPO.ndscm.ts` at the
 * repository root. Each feature or development branch can override this
 * config with its own `REPO.ndscm.ts`, allowing branches to carry
 * branch-specific upstream definitions or tooling versions.
 */
export type RepoConfig = {
  /**
   * Email domain for the repository. Access control identifies users and
   * services by email address. When an email shares this domain, the domain
   * part can be omitted — for example, `"alice"` is equivalent to
   * `"alice@example.com"` if the repo domain is `"example.com"`.
   */
  domain?: string

  commit?: {
    rewrite?: {
      pattern: string
      replace?: string
      finish?: boolean
    }[]
  }

  /**
   * Collaboration surfaces for the repository: where issues are tracked and
   * where pending code changes are discussed. Each surface can be backed by
   * a different system, letting a repo mix ndscm-native tooling with GitHub.
   */
  collaboration?: {
    /**
     * The ticket tracker for issues, bugs, and feature requests.
     */
    tracker?: {
      /**
       * The tracker system.
       *
       * - `"ndscm"` — Stores tickets on a branch.
       * - `"github"` — Uses GitHub Issues.
       */
      system?: "ndscm" | "github"

      /**
       * Branch that stores the tickets. Only used by the `"ndscm"` system.
       * When empty, tickets are stored on the current branch.
       */
      branch?: string
    }

    /**
     * The discussion board for pending code changes.
     */
    review?: {
      /**
       * Backend hosting the review board.
       *
       * - `"ndscm"` — Stores patches and discussions on a branch.
       * - `"github"` — Uses GitHub pull requests.
       */
      system?: "ndscm" | "github"

      /**
       * Branch that stores the patches and discussions. Only used by the
       * `"ndscm"` system. When empty, they are stored on the current branch.
       */
      branch?: string
    }
  }

  /**
   * Upstream sources the repository can sync from. Each entry is keyed by a
   * remote name (for example `"theseed"`) and describes how to fetch and
   * track that source.
   *
   * This config exists to share upstream definitions across the team and
   * across branches in a single, reviewable file. It is not consumed by
   * local git operations: ndscm does not use it to drive `git fetch`,
   * `git pull`, `git rebase`, etc. Local git state (remotes, tracking
   * branches, refspecs) is managed separately by git itself.
   */
  upstream?: {
    [name: string]: {
      /**
       * Source control system used by the upstream. Only `"git"` is
       * supported today.
       *
       * This field is required rather than defaulted so that adding
       * support for additional SCMs in the future does not silently
       * change the meaning of existing configs. Forcing every entry to
       * spell out `scm: "git"` keeps current users from being migrated
       * out from under them when new options appear.
       */
      scm: "git"

      /**
       * Repository URL to fetch from. When omitted, the upstream lives in
       * the same repository as the local branch — i.e., this entry
       * describes a tracking relationship between two refs in the current
       * repo rather than a remote source.
       */
      repo?: string

      /**
       * Whether `tracking` names a local branch instead of a branch on
       * `repo`. Defaults to `false`, in which case `tracking` is resolved
       * against the remote.
       */
      local?: boolean

      /**
       * Name of the branch to track on the upstream side.
       */
      tracking?: string

      /**
       * How the local and upstream chains converge when syncing.
       *
       * - `"rebase"` — Rebase local patches onto the upstream tip.
       *   Local patches are regenerated; the upstream chain stays
       *   unchanged. Use this for feature and development branches.
       *
       * - `"melt"` — Rebase upstream patches onto the local tip.
       *   Upstream patches are regenerated; the local chain stays
       *   unchanged. Use this for long-lived integration branches
       *   that absorb upstream changes without rewriting their own
       *   history.
       */
      converge: "rebase" | "melt"
    }
  }
}
